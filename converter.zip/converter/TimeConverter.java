package converter;

public class TimeConverter extends Converter {
    private double toSeconds(double v, String unit) throws InvalidUnitException {
        switch (unit.toLowerCase()) {
            case "s": case "sec": case "second": return v;
            case "m": case "min": case "minute": return v * 60.0;
            case "h": case "hr": case "hour": return v * 3600.0;
            case "d": case "day": return v * 86400.0;
            default: throw new InvalidUnitException("Unsupported time unit: " + unit);
        }
    }
    private double fromSeconds(double s, String unit) throws InvalidUnitException {
        switch (unit.toLowerCase()) {
            case "s": case "sec": case "second": return s;
            case "m": case "min": case "minute": return s / 60.0;
            case "h": case "hr": case "hour": return s / 3600.0;
            case "d": case "day": return s / 86400.0;
            default: throw new InvalidUnitException("Unsupported time unit: " + unit);
        }
    }
    @Override
    public double convert(String fromUnit, String toUnit, double value) throws InvalidUnitException {
        return fromSeconds(toSeconds(value, fromUnit), toUnit);
    }
}
