// FILE: converter/UnitConverterGUI.java
package converter;

import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class UnitConverterGUI extends Frame implements ActionListener, WindowListener, ItemListener {

    private Choice categoryChoice;
    private Choice fromUnitChoice;
    private Choice toUnitChoice;
    private TextField valueField;
    private TextField resultField;
    private Label statusLabel;
    private Button convertButton;
    private Button historyButton;

    private ConversionHistory history = new ConversionHistory("history.txt");

    public UnitConverterGUI() {
        super("Universal Unit Conversion System");

        setLayout(new GridLayout(7, 2, 5, 5));

        // Category
        add(new Label("Category:"));
        categoryChoice = new Choice();
        categoryChoice.add("Length");
        categoryChoice.add("Weight");
        categoryChoice.add("Temperature");
        categoryChoice.add("Time");
        categoryChoice.add("Speed");
        categoryChoice.add("Volume");
        categoryChoice.addItemListener(this);
        add(categoryChoice);

        // From unit (dropdown)
        add(new Label("From unit:"));
        fromUnitChoice = new Choice();
        add(fromUnitChoice);

        // To unit (dropdown)
        add(new Label("To unit:"));
        toUnitChoice = new Choice();
        add(toUnitChoice);

        // Value
        add(new Label("Value:"));
        valueField = new TextField();
        add(valueField);

        // Result
        add(new Label("Result:"));
        resultField = new TextField();
        resultField.setEditable(false);
        add(resultField);

        // Convert button
        convertButton = new Button("Convert");
        convertButton.addActionListener(this);
        add(convertButton);

        // Show history button
        historyButton = new Button("Show History");
        historyButton.addActionListener(this);
        add(historyButton);

        // Status label
        statusLabel = new Label(" ");
        add(statusLabel);

        addWindowListener(this);
        setSize(450, 300);
        setLocationRelativeTo(null);

        // Initialize units for default category
        updateUnitChoices();
    }

    // Update units in the dropdowns based on selected category
    private void updateUnitChoices() {
        fromUnitChoice.removeAll();
        toUnitChoice.removeAll();

        String category = categoryChoice.getSelectedItem();
        String[] units;

        if ("Length".equals(category)) {
            units = new String[] { "m", "km", "cm", "mm", "in", "ft", "yd", "mi" };
        } else if ("Weight".equals(category)) {
            units = new String[] { "kg", "g", "mg", "lb", "oz", "t" };
        } else if ("Temperature".equals(category)) {
            units = new String[] { "C", "F", "K" };
        } else if ("Time".equals(category)) {
            units = new String[] { "ms", "s", "m", "h", "d", "wk" };
        } else if ("Speed".equals(category)) {
            units = new String[] { "m/s", "km/h", "mph", "ft/s" };
        } else if ("Volume".equals(category)) {
            units = new String[] { "L", "ml", "m3", "cm3", "gal", "pt" };
        } else {
            units = new String[0];
        }

        for (int i = 0; i < units.length; i++) {
            fromUnitChoice.add(units[i]);
            toUnitChoice.add(units[i]);
        }

        if (units.length > 1) {
            fromUnitChoice.select(0);
            toUnitChoice.select(1);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == historyButton) {
            showHistoryWindow();
            return;
        }

        String category = categoryChoice.getSelectedItem();
        String from = fromUnitChoice.getSelectedItem();
        String to = toUnitChoice.getSelectedItem();
        String valueText = valueField.getText().trim();

        if (from == null || to == null || valueText.isEmpty()) {
            statusLabel.setText("Please fill all fields.");
            return;
        }

        double value;
        try {
            value = Double.parseDouble(valueText);
        } catch (NumberFormatException ex) {
            statusLabel.setText("Invalid numeric value.");
            return;
        }

        Converter converter;

        if ("Length".equals(category)) {
            converter = new LengthConverter();
        } else if ("Weight".equals(category)) {
            converter = new WeightConverter();
        } else if ("Temperature".equals(category)) {
            converter = new TemperatureConverter();
        } else if ("Time".equals(category)) {
            converter = new TimeConverter();
        } else if ("Speed".equals(category)) {
            converter = new SpeedConverter();
        } else if ("Volume".equals(category)) {
            converter = new VolumeConverter();
        } else {
            statusLabel.setText("Unknown category.");
            return;
        }

        try {
            double result = converter.convert(from, to, value);
            resultField.setText(String.valueOf(result));
            statusLabel.setText("Conversion successful.");

            String record = history.formatRecord(category, from, to, value, result);
            history.save(record);

        } catch (InvalidUnitException ex) {
            statusLabel.setText(ex.getMessage());
        }
    }

    // History window
    private void showHistoryWindow() {
        Frame historyFrame = new Frame("Conversion History");
        historyFrame.setLayout(new BorderLayout());
        TextArea textArea = new TextArea();
        textArea.setEditable(false);

        try (BufferedReader br = new BufferedReader(new FileReader("history.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                textArea.append(line + "\n");
            }
        } catch (IOException e) {
            textArea.setText("No history available or failed to read history.txt");
        }

        historyFrame.add(textArea, BorderLayout.CENTER);
        historyFrame.setSize(400, 300);
        historyFrame.setLocationRelativeTo(null);
        historyFrame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                historyFrame.dispose();
            }
        });
        historyFrame.setVisible(true);
    }

    // WindowListener
    @Override public void windowOpened(WindowEvent e) {}
    @Override public void windowClosing(WindowEvent e) { dispose(); System.exit(0); }
    @Override public void windowClosed(WindowEvent e) {}
    @Override public void windowIconified(WindowEvent e) {}
    @Override public void windowDeiconified(WindowEvent e) {}
    @Override public void windowActivated(WindowEvent e) {}
    @Override public void windowDeactivated(WindowEvent e) {}

    // ItemListener for category changes
    @Override
    public void itemStateChanged(ItemEvent e) {
        if (e.getSource() == categoryChoice) {
            updateUnitChoices();
        }
    }

    public static void main(String[] args) {
        UnitConverterGUI gui = new UnitConverterGUI();
        gui.setVisible(true);
    }
}
