package converter;

public class DataConverter extends Converter {

    private static final double K = 1024.0;

    private double toBytes(double v, String unit) throws InvalidUnitException {
        switch (unit.toLowerCase()) {
            case "bit":
            case "bits":
                return v / 8.0;

            case "b":
            case "byte":
            case "bytes":
                return v;

            case "kb":
            case "kbyte":
            case "kbytes":
            case "kilobyte":
            case "kilobytes":
                return v * K;

            case "mb":
            case "mbyte":
            case "mbytes":
            case "megabyte":
            case "megabytes":
                return v * K * K;

            case "gb":
            case "gbyte":
            case "gbytes":
            case "gigabyte":
            case "gigabytes":
                return v * K * K * K;

            case "tb":
            case "tbyte":
            case "tbytes":
            case "terabyte":
            case "terabytes":
                return v * K * K * K * K;

            default:
                throw new InvalidUnitException("Unsupported data unit: " + unit);
        }
    }

    private double fromBytes(double bytes, String unit) throws InvalidUnitException {
        switch (unit.toLowerCase()) {
            case "bit":
            case "bits":
                return bytes * 8.0;

            case "b":
            case "byte":
            case "bytes":
                return bytes;

            case "kb":
            case "kbyte":
            case "kbytes":
            case "kilobyte":
            case "kilobytes":
                return bytes / K;

            case "mb":
            case "mbyte":
            case "mbytes":
            case "megabyte":
            case "megabytes":
                return bytes / (K * K);

            case "gb":
            case "gbyte":
            case "gbytes":
            case "gigabyte":
            case "gigabytes":
                return bytes / (K * K * K);

            case "tb":
            case "tbyte":
            case "tbytes":
            case "terabyte":
            case "terabytes":
                return bytes / (K * K * K * K);

            default:
                throw new InvalidUnitException("Unsupported data unit: " + unit);
        }
    }

    @Override
    public double convert(String fromUnit, String toUnit, double value) throws InvalidUnitException {
        return fromBytes(toBytes(value, fromUnit), toUnit);
    }
}
