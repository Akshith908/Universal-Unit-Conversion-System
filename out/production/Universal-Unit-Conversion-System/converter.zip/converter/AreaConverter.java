package converter;

public class AreaConverter extends Converter {

    private double toSquareMeters(double v, String unit) throws InvalidUnitException {
        switch (unit.toLowerCase()) {
            case "m2":
            case "sq m":
            case "sqm":
            case "square meter":
            case "square meters":
                return v;

            case "km2":
            case "square kilometer":
            case "square kilometers":
                return v * 1_000_000.0; // (1000 m)^2

            case "cm2":
            case "square centimeter":
            case "square centimeters":
                return v * 0.0001; // (0.01 m)^2

            case "mm2":
            case "square millimeter":
            case "square millimeters":
                return v * 0.000001; // (0.001 m)^2

            case "ft2":
            case "sq ft":
            case "square foot":
            case "square feet":
                return v * 0.09290304; // (0.3048 m)^2

            case "yd2":
            case "sq yd":
            case "square yard":
            case "square yards":
                return v * 0.83612736; // (0.9144 m)^2

            case "acre":
            case "acres":
                return v * 4046.8564224;

            case "ha":
            case "hectare":
            case "hectares":
                return v * 10_000.0;

            default:
                throw new InvalidUnitException("Unsupported area unit: " + unit);
        }
    }

    private double fromSquareMeters(double m2, String unit) throws InvalidUnitException {
        switch (unit.toLowerCase()) {
            case "m2":
            case "sq m":
            case "sqm":
            case "square meter":
            case "square meters":
                return m2;

            case "km2":
            case "square kilometer":
            case "square kilometers":
                return m2 / 1_000_000.0;

            case "cm2":
            case "square centimeter":
            case "square centimeters":
                return m2 / 0.0001;

            case "mm2":
            case "square millimeter":
            case "square millimeters":
                return m2 / 0.000001;

            case "ft2":
            case "sq ft":
            case "square foot":
            case "square feet":
                return m2 / 0.09290304;

            case "yd2":
            case "sq yd":
            case "square yard":
            case "square yards":
                return m2 / 0.83612736;

            case "acre":
            case "acres":
                return m2 / 4046.8564224;

            case "ha":
            case "hectare":
            case "hectares":
                return m2 / 10_000.0;

            default:
                throw new InvalidUnitException("Unsupported area unit: " + unit);
        }
    }

    @Override
    public double convert(String fromUnit, String toUnit, double value) throws InvalidUnitException {
        return fromSquareMeters(toSquareMeters(value, fromUnit), toUnit);
    }
}
