// File: converter/UnitConverterApp.java
package converter;

import java.util.Scanner;

public class UnitConverterApp {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ConversionHistory history = new ConversionHistory("history.txt");

        System.out.println("=== Universal Unit Conversion System (Console) ===");

        while (true) {
            System.out.println("\nChoose category:");
            System.out.println("1) Length      (m, km, cm, mm, in, ft, yd, mi)");
            System.out.println("2) Weight      (kg, g, mg, lb, oz, t)");
            System.out.println("3) Temperature (C, F, K)");
            System.out.println("4) Time        (ms, s, m, h, d, wk)");
            System.out.println("5) Speed       (m/s, km/h, mph, ft/s)");
            System.out.println("6) Volume      (L, mL, m3, cm3, gal, pt)");
            System.out.println("7) Area        (m2, km2, cm2, mm2, ft2, yd2, acre, ha)");
            System.out.println("8) Data        (bit, B, KB, MB, GB, TB)");
            System.out.println("9) Show history");
            System.out.println("10) Exit");
            System.out.print("Enter choice: ");

            String choice = sc.nextLine().trim();

            // Exit
            if (choice.equals("10")) {
                System.out.println("Goodbye!");
                break;
            }

            // Show history
            if (choice.equals("9")) {
                System.out.println("\n=== Conversion history ===");
                history.showHistory();
                continue;
            }

            Converter converter;
            String category;

            switch (choice) {
                case "1":
                    converter = new LengthConverter();
                    category = "Length";
                    break;
                case "2":
                    converter = new WeightConverter();
                    category = "Weight";
                    break;
                case "3":
                    converter = new TemperatureConverter();
                    category = "Temperature";
                    break;
                case "4":
                    converter = new TimeConverter();
                    category = "Time";
                    break;
                case "5":
                    converter = new SpeedConverter();
                    category = "Speed";
                    break;
                case "6":
                    converter = new VolumeConverter();
                    category = "Volume";
                    break;
                case "7":
                    converter = new AreaConverter();
                    category = "Area";
                    break;
                case "8":
                    converter = new DataConverter();
                    category = "Data";
                    break;
                default:
                    System.out.println("Invalid choice.");
                    continue;
            }

            try {
                System.out.print("From unit: ");
                String from = sc.nextLine().trim();

                System.out.print("To unit: ");
                String to = sc.nextLine().trim();

                System.out.print("Value: ");
                String valueStr = sc.nextLine().trim();
                double value = Double.parseDouble(valueStr);

                double result = converter.convert(from, to, value);

                System.out.printf("Result: %.6f %s%n", result, to);

                String record = history.formatRecord(category, from, to, value, result);
                history.save(record);
            } catch (NumberFormatException e) {
                System.out.println("Invalid numeric value.");
            } catch (InvalidUnitException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }

        sc.close();
    }
}
